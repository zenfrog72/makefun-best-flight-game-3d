// The judge-bar job (server/jobs.ts judge-bar): a judged final's bar games (contracts/competition.ts harness.judge.bar;
// grader/judge-bar.ts, record agent-fun/judge-bar/v1), played on the graders once the final heat has settled, for the
// entries in line for a reward that carry no verdict yet (server/competitions/lifecycle/judge-bar.ts, the bar's debt).
// createJudgeBarHandler's job, in order:
//
//   off        the phase is no final of a bundle naming a bar (judgeBarPhaseOf: a dev phase, a bundle naming none):
//              nothing is played. A blind round never sends one, and a final heat record a blind round wrote is refused
//              below
//   none       the competition was cancelled or resolved, its final is not locked, its board cannot be ranked, or
//              every entry in line carries its verdict (judgeBarOwed): nothing is owed
//   waiting    an entry taken in by the deadline awaits its snapshot or transcripts gate, a final grade is in flight or
//              owed, or the final heat owes a verdict (judgeBarWaitOf): handed on to the next JUDGE_BAR_RECHECK_MS slot's
//              job (judgeBarJobId `wait:<slot>`), since the bar is judged like the settled heat
//   the final  the settled final heat record: the blob every owed entry's latest final grade run names
//              (run.judge_heat_sha256), one record for all of them, a final's (stage `final`, a format the bar judges
//              like: grader/judge-bar.ts JUDGE_BAR_FINAL_FORMATS), held whole (parseJudgeHeatRecord), on the bundle's
//              judge (its directory digest, media and artifact), its `judges` named (a final planned on OpenRouter),
//              never a blind round's (blind_round.heat_record_sha256), and every owed entry's judged artifact one of its
//              entrant members. A run with no record, a record that does not hold or any of the rest is a
//              PermanentJobError (paged by the pipeline: judgeBarDeadPage): the heat is not settled, or not this
//              final's. A record the blob store does not hold is a plain Error, retried
//   the bar    the bundle's sealed bar directory read and held to bar_sha256 (grader/worker.ts readJudgeBarDir, as
//              readJudgeTreeAsync holds the judge directory) and the judge directory's prompt (judgedTreesOf,
//              readJudgeTreeAsync): a bar that does not read is the bundle's fault, a PermanentJobError
//   the twin   an owed entry whose judged artifact is byte for byte the bar's own (which the setup refuses as a
//              subject) is no game anyone can decide: the job is refused for good before any call
//              (server/competitions/lifecycle/judge-bar.ts JudgeBarTwinError, its words naming the entries' ids,
//              paged by judgeBarDeadPage) and writes no row, so the debt stays owed and every reader of the result
//              keeps waiting, never paying on no verdict. An admin disqualifies each as a copy of the bar (its
//              finalist review's disqualify while the window is open, else the admin desk's, until the results are
//              posted), which moves the line (barLineOf reads the decided review, the desk's failed status) and sends
//              the next job at once (lifecycle/judge-bar.ts sendJudgeBarReplay), which plays the line it leaves. A dossier bar holds no game files, so it never passes the scorer's gate as an
//              entry's: the guard is an image or text bundle's
//   subjects   the owed entries grouped by their judged artifact, in place order (judgeBarOwed's), each read back
//              from the blob store by its sha256 (judgeHeatMemberRead)
//   the view   a final judged on judge views (its record's judge_view): each subject sent as the view the final sent
//              (else the one indexed for it, else made), and the bar's view made at the final's policy and the
//              contest's entry budget (grader/worker.ts judgeBarViewOf: judgeViewOf, a per-process memo), stored
//              before the first call; a bar view that cannot be made is the bundle's fault, a PermanentJobError
//   the setup  grader/judge-bar.ts JudgeBarSetup: the phase, the final heat (its sha256 and format), the bar, the
//              subjects, the final record's `judges` and `panel` verbatim, the prompt's sha256 and the view; its plan
//              judgeBarPlan, its resume key judgeBarResumeKey of it, the bundle's sha256 and the prompt's
//   played     grader/worker.ts playJudgeBar (deps.play): on the final's judges alone, each on its own OpenRouter pin,
//              a final's pool heat at its adaptive width (deps.judge.concurrency fixes it: off production one call in
//              flight), each call kept as it settles under the resume key so a retry asks only the calls still to
//              come. A share of calls with no verdict over the final record's invalid_share_max fails the attempt
//              (retried as the platform's fault): it never becomes a verdict, and no row is written
//   recorded   the record stored (canonical JSON, by its sha256) before its verdicts: each entry its subject's verdict
//              (points over the games, of 20 x games, beats above half), every row naming that record (as the final
//              kit's reveal and verify-result read each row against a judge-bar/v1 record), written with its
//              judge_bar check in one transaction (recordJudgeBar, each row once). The partial is dropped once they
//              are written. Then
//              judgeBarOwed is read again: an entry moved into line since (a finalist review's disqualification) is
//              owed its turn, so the phase's next job is sent (judgeBarJobId `next:<job id>`)
//
// Sealed (the games stay sealed until the results are posted): every log line, the job's answer and every error it
// fails with carry counts only, every sha256 masked, never an entry's verdict or points. It writes no run, score or
// live document (GET /live is unchanged): only the record blob, the judge_bar rows and checks, its judge keys and its
// partial. A job that dies for good is paged by server/pipeline/index.ts (judgeBarDeadPage).
//
// It names a new harness_version (grader/version.ts sums every grader/ source).

import { and, eq, inArray } from 'drizzle-orm';
import type { ProgramJudgeT } from '../contracts/competition.ts';
import type { ScoreT } from '../contracts/score.ts';
import { blindRound, run } from '../server/db/schema.ts';
import type { JudgeBarOwed, JudgeBarPhase, JudgeBarRecorded } from '../server/competitions/lifecycle/judge-bar.ts';
import { JUDGE_BAR_RECHECK_MS, judgeBarJobId, PermanentJobError, type JobContext, type JobPayload, type JobQueue } from '../server/jobs.ts';
import { DOSSIER_VIEW_ENTRY_TOKENS, dossierViewBudgetOf } from '../server/judging/dossier-view-budget.ts';
import { compareCodeUnits, sha256Hex } from '../sim/canonical.ts';
import type { JudgeBarSetupT, JudgeBarSubjectT } from './judge-bar.ts';
import type { JudgeHeatRecordT } from './judge-heat.ts';
import {
  judgeBarPartialOf,
  judgeBarSealed,
  judgeBarViewOf,
  judgedTreesOf,
  judgeHeatMemberRead,
  playJudgeBar,
  readJudgeBarDir,
  readJudgeTreeAsync,
  type GradeWorkerDeps,
  type JudgeBarHeatEnd,
  type JudgeBarHeatInput,
} from './worker.ts';

/** How a judge-bar job ended (the header). */
export type JudgeBarJobEndedT = 'off' | 'none' | 'waiting' | 'recorded';

/** A judge-bar job's answer: counts only (the header's sealed). */
export interface JudgeBarJobOutcome {
  phase_id: string;
  ended: JudgeBarJobEndedT;
  /** Why nothing was recorded (off, none, waiting), sealed. */
  why: string | null;
  /** The entries decided by this job (their rows written or found written), the games' calls and those an earlier attempt kept. */
  decided: number;
  /** Of them, the entries whose row this job wrote. */
  written: number;
  calls: number;
  kept_calls: number;
  /** The job sent on: a wait's hand-on, or the next job for the entries moved into line since; null when none (or it was sent before). */
  next: string | null;
}

/** What plays the bar's calls (grader/worker.ts playJudgeBar, the default): a test's stub judge stands in. */
export type JudgeBarPlay = (deps: Pick<GradeWorkerDeps, 'blobs' | 'objects' | 'workRoot' | 'judge' | 'log' | 'now'>, input: JudgeBarHeatInput) => Promise<JudgeBarHeatEnd>;

/**
 * What the job reads and plays through: the grade jobs' deps (the judge's planner, fetch and width among them: a fixed
 * `judge.concurrency`, off production 1, else the final's adaptive width), the queue it hands on to and sends the next
 * job on (`jobs`), and whether final grading is refused where it runs (`finalRefused`, the re-drives judgeBarWaitOf
 * waits on). `waitOf` and `play` are the lifecycle's judgeBarWaitOf and grader/worker.ts playJudgeBar unless given.
 */
export type JudgeBarJobDeps = Pick<GradeWorkerDeps, 'db' | 'blobs' | 'objects' | 'workRoot' | 'competitionDir' | 'judge' | 'log' | 'now'> & {
  jobs: Pick<JobQueue, 'send'>;
  finalRefused?: boolean;
  waitOf?: (db: GradeWorkerDeps['db'], p: Pick<JudgeBarPhase, 'comp' | 'ph' | 'bundle'>, read: { now: Date; finalRefused: boolean }) => Promise<string | null>;
  play?: JudgeBarPlay;
};

/** A run status whose score stands (as the kit and the publish stage read one). */
const SCORED_RUN_STATUSES: ReadonlySet<string> = new Set(['finished', 'nondeterministic']);

/** A grade run as the job reads one of an owed entry's (finalRunsOf). */
interface FinalRun {
  id: string;
  attempt: number;
  createdAt: Date;
  status: string;
  judgeHeatSha256: string | null;
  result: unknown;
}

/** Each of `ids`' latest grade run on phase `phaseId` (a higher attempt, then created later, then the higher id: as the board picks it). */
async function finalRunsOf(db: GradeWorkerDeps['db'], phaseId: string, ids: readonly string[]): Promise<Map<string, FinalRun>> {
  const rows = await db
    .select({ submissionId: run.submissionId, id: run.id, attempt: run.attempt, createdAt: run.createdAt, status: run.status, judgeHeatSha256: run.judgeHeatSha256, result: run.result })
    .from(run)
    .where(and(eq(run.phaseId, phaseId), eq(run.kind, 'grade'), inArray(run.submissionId, [...ids])));
  const latest = new Map<string, FinalRun>();
  const later = (a: FinalRun, b: FinalRun): boolean => (a.attempt !== b.attempt ? a.attempt > b.attempt : a.createdAt.getTime() !== b.createdAt.getTime() ? a.createdAt.getTime() > b.createdAt.getTime() : a.id > b.id);
  for (const r of rows) {
    const key = r.submissionId.toLowerCase();
    const cur = latest.get(key);
    if (cur === undefined || later(r, cur)) latest.set(key, r);
  }
  return latest;
}

/** The judged artifact a final grade's score names (performance.judge.artifact_sha256), or null. */
function judgedArtifactOf(result: unknown): string | null {
  const perf = (result as Partial<ScoreT> | null)?.performance as { kind?: unknown; judge?: { artifact_sha256?: unknown } } | undefined;
  const sha = perf?.judge?.artifact_sha256;
  return typeof sha === 'string' && /^[0-9a-f]{64}$/.test(sha) ? sha : null;
}

/**
 * `err` as the job fails with it (the header's sealed): itself when it names no sha256, else one of its kind with the
 * message masked and no cause: a PermanentJobError of its own class (a JudgeBarTwinError stays one, so its page names
 * its fix), any other a plain Error.
 */
function sealedError(err: unknown): unknown {
  if (!(err instanceof Error)) return new Error(judgeBarSealed(String(err)));
  if (!/[0-9a-f]{64}/i.test(`${err.message}\n${err.stack ?? ''}`)) return err;
  const text = judgeBarSealed(err.message);
  const out = err instanceof PermanentJobError ? new (err.constructor as new (message: string) => PermanentJobError)(text) : new Error(text);
  out.stack = `${out.name}: ${text}`;
  return out;
}

/**
 * The judge-bar job's handler (the header): `deps` the grade jobs' (the judge's planner and fetch), the queue and the
 * refusal of final grading. Its answer carries counts only; what decides nothing throws (a PermanentJobError when no
 * retry mends it, else a plain Error the queue retries from the calls kept), sealed.
 */
export function createJudgeBarHandler(deps: JudgeBarJobDeps): (data: JobPayload<'judge-bar'>, ctx: Pick<JobContext, 'id'> & Partial<Pick<JobContext, 'signal'>>) => Promise<JudgeBarJobOutcome> {
  return async (data, ctx) => {
    try {
      return await judgeBarJob(deps, data, ctx);
    } catch (err) {
      if (ctx.signal?.aborted === true && err === ctx.signal.reason) throw err;
      throw sealedError(err);
    }
  };
}

async function judgeBarJob(deps: JudgeBarJobDeps, data: JobPayload<'judge-bar'>, ctx: Pick<JobContext, 'id'> & Partial<Pick<JobContext, 'signal'>>): Promise<JudgeBarJobOutcome> {
  const { db } = deps;
  const log = (line: string): void => (deps.log ?? ((l: string) => console.log(l)))(judgeBarSealed(line));
  const now = (deps.now ?? (() => new Date()))();
  const phaseId = data.phase_id.toLowerCase();
  const end = (ended: JudgeBarJobEndedT, why: string | null, o: Partial<Pick<JudgeBarJobOutcome, 'decided' | 'written' | 'calls' | 'kept_calls' | 'next'>> = {}): JudgeBarJobOutcome => ({
    phase_id: phaseId,
    ended,
    why: why === null ? null : judgeBarSealed(why),
    decided: o.decided ?? 0,
    written: o.written ?? 0,
    calls: o.calls ?? 0,
    kept_calls: o.kept_calls ?? 0,
    next: o.next ?? null,
  });
  const lc = await import('../server/competitions/lifecycle/judge-bar.ts');
  const p = await lc.judgeBarPhaseOf(db, phaseId);
  if (p === null) {
    log(`[judge-bar] phase ${phaseId}: off, it is not the final phase of a bundle naming a bar (harness.judge.bar)`);
    return end('off', 'the phase is not the final phase of a bundle naming a bar (harness.judge.bar)');
  }
  const { comp, ph, bundle, harness, bar } = p;
  const judge = harness.judge as ProgramJudgeT;
  const what = `the bar games of ${comp.slug}'s final phase ${ph.id}`;
  const say = (line: string): void => log(`[judge-bar] ${comp.slug} final phase ${ph.id}: ${line}`);
  const refuse = (why: string): PermanentJobError => new PermanentJobError(judgeBarSealed(`${what}: ${why}`));
  if (comp.status === 'cancelled' || comp.cancelledAt !== null) return end('none', `${comp.slug} was cancelled: it awards nothing, so no bar is played`);
  if (comp.resolvedAt !== null || comp.status === 'resolved') return end('none', `${comp.slug} was resolved: its rewards are decided`);
  if (ph.lockedAt === null) return end('none', `the final phase of ${comp.slug} is not locked: its entries are graded and judged first`);

  // What the games wait on: the grading and the final heat, which they are judged like.
  const waits = await (deps.waitOf ?? lc.judgeBarWaitOf)(db, p, { now, finalRefused: deps.finalRefused === true });
  if (waits !== null) {
    const slot = Math.floor(now.getTime() / JUDGE_BAR_RECHECK_MS) + 1;
    const next = await lc.sendJudgeBarJob(deps.jobs, ph.id, { id: judgeBarJobId(ph.id, `wait:${slot}`), startAfter: new Date(slot * JUDGE_BAR_RECHECK_MS) });
    say(`waiting: ${waits}; handed on to the next slot's job (${next ?? 'sent before'})`);
    return end('waiting', waits, { next });
  }
  const owed: JudgeBarOwed = await lc.judgeBarOwed(db, comp, ph, bundle);
  if (owed.unranked !== null) return end('none', `${comp.slug}'s final phase cannot be ranked (${owed.unranked}), so no entry is in line for a reward yet`);
  if (owed.owed.length === 0) return end('none', `every entry in line for a reward on ${comp.slug}'s final phase (${owed.inLine.length}) carries its bar verdict`);

  // The settled final heat record every owed entry's final grade names.
  const runs = await finalRunsOf(db, ph.id, owed.owed);
  const artifactOf = new Map<string, string>();
  const records = new Set<string>();
  for (const id of owed.owed) {
    const r = runs.get(id.toLowerCase());
    if (r === undefined || !SCORED_RUN_STATUSES.has(r.status)) throw refuse(`entry ${id}, in line for a reward, has no scored final grade: the final heat is not settled, and the bar is judged like it`);
    if (r.judgeHeatSha256 === null) throw refuse(`entry ${id}'s final grade names no judge heat record: the final heat is not settled, and the bar is judged like it`);
    const art = judgedArtifactOf(r.result);
    if (art === null) throw refuse(`entry ${id}'s final grade names no judged artifact`);
    artifactOf.set(id, art);
    records.add(r.judgeHeatSha256);
  }
  if (records.size !== 1) throw refuse(`the entries in line name ${records.size} judge heat records: one settled final heat judges them all`);
  const finalSha = [...records][0]!;
  const [blind] = await db
    .select({ id: blindRound.id })
    .from(blindRound)
    .where(and(eq(blindRound.competitionId, comp.id), eq(blindRound.heatRecordSha256, finalSha)))
    .limit(1);
  if (blind !== undefined) throw refuse("the judge heat record the entries name is a blind round's: no bar is played on a blind round, only after the final heat");
  const stored = await deps.blobs.get(finalSha);
  if (stored === null) throw new Error(judgeBarSealed(`${what}: the blob store holds no final heat record ${finalSha}: the job tries again`));
  const jh = await import('./judge-heat.ts');
  const jb = await import('./judge-bar.ts');
  let final: JudgeHeatRecordT;
  try {
    final = jh.parseJudgeHeatRecord(stored);
  } catch (err) {
    if (!(err instanceof jh.JudgeHeatError)) throw err;
    throw refuse(`its final heat record does not hold (${err.message}): the heat is not settled`);
  }
  const format = final.format;
  if (final.stage !== 'final') throw refuse(`the judge heat record the entries name is a ${final.stage} heat's, not a final's`);
  if (!(jb.JUDGE_BAR_FINAL_FORMATS as readonly string[]).includes(format)) throw refuse(`its final heat record is ${format}, which no bar is judged like (${jb.JUDGE_BAR_FINAL_FORMATS.join(', ')})`);
  if (final.judge_sha256 !== judge.judge_sha256 || final.media !== judge.media || final.artifact !== judge.artifact) throw refuse("its final heat record was judged on another judge (its directory, media or artifact) than the bundle's");
  const judges = final.judges;
  if (judges === undefined) throw refuse("its final heat record names no judges (it was judged on the bundle's own judge, not a plan's on OpenRouter): a bar is judged like its final on OpenRouter alone");
  const members = new Map(final.field.map((m) => [m.artifact_sha256, m]));
  for (const [id, art] of artifactOf) {
    const m = members.get(art);
    if (m === undefined || m.entries.length === 0) throw refuse(`entry ${id}'s judged artifact is no entrant member of its final heat record`);
  }

  // The bar, read and held to its seal.
  const barRead = await readJudgeBarDir(deps, comp.slug, harness, judge);
  if ('refused' in barRead) throw refuse(`${barRead.refused}: the bundle's bar is broken`);

  // An entry in a paid place that is the bar itself: no game decides it, so nothing is played and no row written (the
  // debt stays owed, the results wait) until an admin disqualifies it and the line moves.
  const twins = owed.owed.filter((id) => artifactOf.get(id) === barRead.sha256);
  if (twins.length > 0) {
    const one = twins.length === 1;
    const named = `${one ? 'entry' : 'entries'} ${twins.join(', ')}`;
    throw new lc.JudgeBarTwinError(
      judgeBarSealed(
        `${what}: ${named}, in a paid place, ${one ? 'is' : 'are'} the bar itself (${bar.name}): ${one ? 'its' : 'their'} judged artifact is byte for byte the bar's, so no game can decide ${one ? 'it' : 'them'}, and nothing is played or recorded. ` +
          `An admin disqualifies ${one ? 'it' : 'each'} as a copy of the bar (its finalist review's disqualify while the review window is open, else the admin desk's disqualify, open until the results are posted; either sends the bar games again at once), and the bar games then play the line ${one ? 'it leaves' : 'they leave'}`,
      ),
    );
  }

  // The judge's prompt, its directory held to its seal.
  const trees = await judgedTreesOf(deps, comp.slug, harness, judge);
  const dir = await readJudgeTreeAsync(trees.judgeDir, judge);
  if ('refused' in dir) throw refuse(dir.refused);

  // The subjects, one a distinct artifact in place order.
  const grouped = new Map<string, string[]>();
  for (const id of owed.owed) {
    const art = artifactOf.get(id)!;
    const list = grouped.get(art);
    if (list === undefined) grouped.set(art, [id]);
    else list.push(id);
  }
  const bytes = new Map<string, Uint8Array>();
  const subjects: JudgeBarSubjectT[] = [];
  for (const [art, ids] of grouped) {
    const b = await judgeHeatMemberRead(deps.blobs, art);
    if (b === null) throw new Error(judgeBarSealed(`${what}: the blob store holds no judged artifact ${art} of an entry in line: the job tries again`));
    bytes.set(art, b);
    subjects.push({ artifact_sha256: art, artifact_bytes: b.byteLength, entries: [...ids].sort(compareCodeUnits) });
  }

  // A final judged on views: the subjects' views the final sent, the bar's made at its policy and the contest's budget.
  let view: JudgeBarSetupT['judge_view'];
  if (final.judge_view !== undefined) {
    const made = await judgeBarViewOf({ blobs: deps.blobs, db }, { finalView: final.judge_view, entryTokens: dossierViewBudgetOf(comp.slug) ?? DOSSIER_VIEW_ENTRY_TOKENS, subjects: bytes, bar: barRead });
    if ('unmade' in made) throw refuse(made.bar ? `the bar's judge view cannot be made (${made.unmade}): the bundle's bar is broken` : `a subject's judge view cannot be made (${made.unmade})`);
    view = made.view;
  }
  const setup: JudgeBarSetupT = {
    phase_id: ph.id.toLowerCase(),
    final_heat: { sha256: finalSha, format: format as JudgeBarSetupT['final_heat']['format'] },
    bar: { name: bar.name, bar_sha256: bar.bar_sha256, artifact_sha256: barRead.sha256, artifact_bytes: barRead.bytes.byteLength, games: bar.games },
    subjects,
    judges: [...judges],
    ...(final.panel === undefined ? {} : { panel: final.panel }),
    prompt_sha256: sha256Hex(dir.prompt),
    ...(view === undefined ? {} : { judge_view: view }),
  };
  const issues = jb.judgeBarSetupIssues(setup);
  if (issues.length > 0) throw refuse(`its setup does not hold: ${issues.slice(0, 3).join('; ')}`);
  const resumeKey = jb.judgeBarResumeKey(setup, { bundle_sha256: comp.bundleSha256 ?? null, prompt_sha256: setup.prompt_sha256 });
  const artifacts = new Map(bytes);
  artifacts.set(barRead.sha256, barRead.bytes);
  say(`playing the bar for ${owed.owed.length} entries (${subjects.length} distinct artifacts) in ${bar.games} games each, ${jb.judgeBarPlannedCalls(setup)} calls, judged as its ${format} final's playoff on ${judges.length} judges`);
  const played: JudgeBarHeatEnd = await (deps.play ?? playJudgeBar)(deps, {
    slug: comp.slug,
    phaseId: ph.id,
    setup,
    final,
    prompt: dir.prompt,
    artifacts,
    resumeKey,
    ...(ctx.signal === undefined ? {} : { signal: ctx.signal }),
  });

  // The verdicts: each entry its subject's, its row naming the bar record that decided it.
  const verdicts: JudgeBarRecorded[] = [];
  for (const v of played.record.verdicts) {
    for (const e of v.entries) verdicts.push({ submission_id: e, artifact_sha256: v.artifact_sha256, record_sha256: played.sha256, games: bar.games, points: v.points, max: v.max, beats: v.beats });
  }
  const written = await lc.recordJudgeBar(db, comp, ph, bar, verdicts, now);
  // Its calls are recorded: the partial goes (a fault is said: the next heat's key is another).
  try {
    await (await judgeBarPartialOf(deps, ph.id, resumeKey)).remove();
  } catch (err) {
    say(`its kept calls could not be dropped (${err instanceof Error ? err.message : String(err)})`);
  }
  const after = await lc.judgeBarOwed(db, comp, ph, bundle);
  const next = after.owed.length === 0 ? null : await lc.sendJudgeBarJob(deps.jobs, ph.id, { id: judgeBarJobId(ph.id, `next:${ctx.id}`) });
  say(
    `decided ${verdicts.length} entries (${written.length} rows written), ${played.record.calls.length} calls (${played.kept_calls} kept from an earlier attempt)` +
      (after.owed.length === 0 ? '' : `; ${after.owed.length} entries moved into line since, sent on (job ${next ?? 'sent before'})`),
  );
  return end('recorded', null, { decided: verdicts.length, written: written.length, calls: played.record.calls.length, kept_calls: played.kept_calls, next });
}
